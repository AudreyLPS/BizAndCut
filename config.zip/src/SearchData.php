<?php

namespace App\src;

class SearchData
{
    /**
     * @var string
     */
    public $q ='';
    
}