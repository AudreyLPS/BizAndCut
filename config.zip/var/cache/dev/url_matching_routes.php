<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/bizandcut/listepropositions' => [[['_route' => 'bizandcut.propositions.index', '_controller' => 'App\\Controller\\Bizandcut\\PropositionsController::index'], null, null, null, false, false, null]],
        '/bizandcut/listeusers' => [[['_route' => 'bizandcut.users.index', '_controller' => 'App\\Controller\\Bizandcut\\UsersController::index'], null, null, null, true, false, null]],
        '/coiffeur/listdevis' => [[['_route' => 'coiffeur.devis.index', '_controller' => 'App\\Controller\\Coiffeur\\DevisController::index'], null, null, null, false, false, null]],
        '/coiffeur/participation' => [[['_route' => 'coiffeur.participation.index', '_controller' => 'App\\Controller\\Coiffeur\\ParticipationsController::index'], null, null, null, false, false, null]],
        '/entreprise/listdevis' => [[['_route' => 'entreprise.devis.index', '_controller' => 'App\\Controller\\Entreprise\\DevisController::index'], null, null, null, false, false, null]],
        '/entreprise/devis/form' => [[['_route' => 'entreprise.devis.form', '_controller' => 'App\\Controller\\Entreprise\\DevisController::formEvenement'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'homepage.index', '_controller' => 'App\\Controller\\HomepageController::index'], null, null, null, false, false, null]],
        '/prestationDeCoiffure' => [[['_route' => 'bizAndCutOtherPage.prestationDeCoiffure.index', '_controller' => 'App\\Controller\\HomepageController::indexPrestationDeCoiffure'], null, null, null, false, false, null]],
        '/commentCaMarche' => [[['_route' => 'bizAndCutOtherPage.commentCaMarche.index', '_controller' => 'App\\Controller\\HomepageController::indexCommentCaMarche'], null, null, null, false, false, null]],
        '/commentCaMarcheCoiffeur' => [[['_route' => 'bizAndCutOtherPage.commentCaMarche.indexCoiffeur', '_controller' => 'App\\Controller\\HomepageController::indexCommentCaMarcheCoiffeur'], null, null, null, false, false, null]],
        '/detailsDeNosPrestation' => [[['_route' => 'bizAndCutOtherPage.detailsDeNosPrestation.index', '_controller' => 'App\\Controller\\HomepageController::indexDetailsDeNosPrestation'], null, null, null, false, false, null]],
        '/bizandcut' => [[['_route' => 'bizandcut.homepage.index', '_controller' => 'App\\Controller\\HomepageController::indexBC'], null, null, null, false, false, null]],
        '/coiffeur' => [[['_route' => 'coiffeur.homepage.index', '_controller' => 'App\\Controller\\HomepageController::indexCoiffeurs'], null, null, null, false, false, null]],
        '/entreprise' => [[['_route' => 'entreprise.homepage.index', '_controller' => 'App\\Controller\\HomepageController::indexEntreprise'], null, null, null, false, false, null]],
        '/salarie' => [[['_route' => 'salarie.homepage.index', '_controller' => 'App\\Controller\\HomepageController::indexSalarie'], null, null, null, false, false, null]],
        '/rdv' => [[['_route' => 'rdv.creneaux.index', '_controller' => 'App\\Controller\\Rdv\\RdvController::index'], null, null, null, true, false, null]],
        '/rdv/form' => [[['_route' => 'rdv.creneaux.form', '_controller' => 'App\\Controller\\Rdv\\RdvController::formEvenement'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/bizandcut/(?'
                    .'|profil/([^/]++)(*:198)'
                    .'|liste(?'
                        .'|propositions/set/([^/]++)/([^/]++)(*:248)'
                        .'|users/(?'
                            .'|active/([^/]++)(*:280)'
                            .'|desactive/([^/]++)(*:306)'
                        .')'
                    .')'
                .')'
                .'|/coiffeur/(?'
                    .'|p(?'
                        .'|articipations/(?'
                            .'|accepte/([^/]++)/([^/]++)(*:376)'
                            .'|decline/([^/]++)(*:400)'
                        .')'
                        .'|ro(?'
                            .'|fil/(?'
                                .'|([^/]++)(*:429)'
                                .'|form(?'
                                    .'|(*:444)'
                                    .'|/update(?:/([^/]++))?(*:473)'
                                .')'
                            .')'
                            .'|position/delete/([^/]++)(*:507)'
                        .')'
                    .')'
                    .'|liste/form/([^/]++)(*:536)'
                .')'
                .'|/entreprise/(?'
                    .'|devis/(?'
                        .'|form/update(?:/([^/]++))?(*:594)'
                        .'|delete/([^/]++)(*:617)'
                    .')'
                    .'|satisfaction/([^/]++)(*:647)'
                    .'|listepropositions/(?'
                        .'|([^/]++)(*:684)'
                        .'|set/([^/]++)/([^/]++)(*:713)'
                    .')'
                .')'
                .'|/register/([^/]++)(*:741)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        198 => [[['_route' => 'bizandcut.profil.index', '_controller' => 'App\\Controller\\Bizandcut\\ProfilController::index'], ['coiffeur'], null, null, false, true, null]],
        248 => [[['_route' => 'bizandcut.propositions.accepte', '_controller' => 'App\\Controller\\Bizandcut\\PropositionsController::accepte'], ['id', 'idDevis'], null, null, false, true, null]],
        280 => [[['_route' => 'bizandcut.users.active', '_controller' => 'App\\Controller\\Bizandcut\\UsersController::active'], ['id'], null, null, false, true, null]],
        306 => [[['_route' => 'bizandcut.users.desactive', '_controller' => 'App\\Controller\\Bizandcut\\UsersController::desactive'], ['id'], null, null, false, true, null]],
        376 => [[['_route' => 'coiffeur.participations.accepte', '_controller' => 'App\\Controller\\Coiffeur\\ParticipationsController::accepte'], ['idDevis', 'idCoiffeur'], null, null, false, true, null]],
        400 => [[['_route' => 'coiffeur.participations.decline', '_controller' => 'App\\Controller\\Coiffeur\\ParticipationsController::decline'], ['id'], null, null, false, true, null]],
        429 => [[['_route' => 'coiffeur.profil.index', '_controller' => 'App\\Controller\\Coiffeur\\ProfilController::index'], ['coiffeur'], null, null, false, true, null]],
        444 => [[['_route' => 'coiffeur.profil.form', '_controller' => 'App\\Controller\\Coiffeur\\ProfilController::form'], [], null, null, false, false, null]],
        473 => [[['_route' => 'coiffeur.profil.form.update', 'id' => null, '_controller' => 'App\\Controller\\Coiffeur\\ProfilController::form'], ['id'], null, null, false, true, null]],
        507 => [[['_route' => 'coiffeur.propositions.delete', '_controller' => 'App\\Controller\\Coiffeur\\PropositionsController::delete'], ['id'], null, null, false, true, null]],
        536 => [[['_route' => 'coiffeur.propositions.form', '_controller' => 'App\\Controller\\Coiffeur\\PropositionsController::form'], ['id'], null, null, false, true, null]],
        594 => [[['_route' => 'entreprise.devis.form.update', 'id' => null, '_controller' => 'App\\Controller\\Entreprise\\DevisController::formEvenement'], ['id'], null, null, false, true, null]],
        617 => [[['_route' => 'entreprise.devis.delete', '_controller' => 'App\\Controller\\Entreprise\\DevisController::delete'], ['id'], null, null, false, true, null]],
        647 => [[['_route' => 'entreprise.satisfaction.send', '_controller' => 'App\\Controller\\Entreprise\\DevisController::send'], ['event'], null, null, false, true, null]],
        684 => [[['_route' => 'entreprise.propositions.index', '_controller' => 'App\\Controller\\Entreprise\\PropositionsController::index'], ['idDevis'], null, null, false, true, null]],
        713 => [[['_route' => 'entreprise.propositions.accepte', '_controller' => 'App\\Controller\\Entreprise\\PropositionsController::accepte'], ['id', 'idDevis'], null, null, false, true, null]],
        741 => [
            [['_route' => 'app_register', '_controller' => 'App\\Controller\\RegistrationController::register'], ['typeUser'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
