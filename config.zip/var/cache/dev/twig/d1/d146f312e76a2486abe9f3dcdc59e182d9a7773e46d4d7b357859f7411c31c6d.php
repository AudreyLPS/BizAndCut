<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entreprise/propositions/index.html.twig */
class __TwigTemplate_8a56a24648c79b4f8428047f148baef16ce72a13f7671d5381c17df392b0da58 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "entreprise/propositions/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "entreprise/propositions/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "entreprise/propositions/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t";
        // line 6
        $this->loadTemplate("_inc/flash.messages.html.twig", "entreprise/propositions/index.html.twig", 6)->display($context);
        // line 7
        echo "\t\t\t<h1>Liste des propositions</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Evénement</th>
\t\t\t\t<th>Fait par</th>
\t\t\t\t<th>Fait le</th>
\t\t\t\t<th>Montant</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 25, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["proposition"]) {
            echo " 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 27), "libelle", [], "any", false, false, false, 27), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "coiffeur", [], "any", false, false, false, 28), "nom", [], "any", false, false, false, 28), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 29
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "dateProposition", [], "any", false, false, false, 29), "m/d/Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "montant", [], "any", false, false, false, 30), "html", null, true);
            echo "€</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t\t<a href=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.propositions.accepte", ["id" => twig_get_attribute($this->env, $this->source, $context["proposition"], "id", [], "any", false, false, false, 32), "idDevis" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 32), "id", [], "any", false, false, false, 32)]), "html", null, true);
            echo "\" class=\"btn btn-success col-md-4\">Accepter</a>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['proposition'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "\t\t</table>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "entreprise/propositions/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 36,  118 => 32,  113 => 30,  109 => 29,  105 => 28,  101 => 27,  94 => 25,  74 => 7,  72 => 6,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t{% include \"_inc/flash.messages.html.twig\" %}
\t\t\t<h1>Liste des propositions</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Evénement</th>
\t\t\t\t<th>Fait par</th>
\t\t\t\t<th>Fait le</th>
\t\t\t\t<th>Montant</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t{% for proposition in results %} 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">{{ proposition.devis.libelle }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.coiffeur.nom }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.dateProposition|date(\"m/d/Y\") }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.montant }}€</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t\t<a href=\"{{ url('entreprise.propositions.accepte', { id:proposition.id, idDevis:proposition.devis.id }) }}\" class=\"btn btn-success col-md-4\">Accepter</a>
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t{% endfor %}
\t\t</table>
\t</div>
{% endblock %}









", "entreprise/propositions/index.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\entreprise\\propositions\\index.html.twig");
    }
}
