<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _inc/nav.html.twig */
class __TwigTemplate_ed4ec4ba187dd85d882874c78a4fd2733d81ad1978e2ce783ac0193ae6be06ec extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/nav.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/nav.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo01\" aria-controls=\"navbarTogglerDemo01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>
  <div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo01\">
    <!--a class=\"navbar-brand\" >Biz&Cut</a-->
    <a  href=\"";
        // line 7
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("homepage.index");
        echo "\">
      <img src=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/logo_blanc.png"), "html", null, true);
        echo "\" width=\"150\" class=\"img-fluid\"/>
    </a>
    <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
      <li class=\"nav-item active\">
      </li>
    </ul>

    ";
        // line 15
        if ( !$this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 16
            echo "    <ul class=\"navbar-nav justify-content-end\">
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"";
            // line 18
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizAndCutOtherPage.prestationDeCoiffure.index");
            echo "\">Prestation de coiffure sur votre lieu de travail</a>
      </li>
      <li class=\"nav-item dropdown\">
        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
          Comment ça marche ? </a>
        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdownMenuLink\">\t
          <a href=\"";
            // line 24
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizAndCutOtherPage.commentCaMarche.index");
            echo "\" class=\"dropdown-item\"> Pour les entreprises </a>
          <a href=\"";
            // line 25
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizAndCutOtherPage.commentCaMarche.indexCoiffeur");
            echo "\" class=\"dropdown-item\"> Pour les coiffeurs </a>
        </div>
      </li>
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"";
            // line 29
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizAndCutOtherPage.detailsDeNosPrestation.index");
            echo "\">Nos prestations</a>
      </li>
      <li class=\"nav-item dropdown\">
        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
          Inscription </a>
        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdownMenuLink\">\t
          <a href=\"";
            // line 35
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_register", ["typeUser" => "entreprises"]);
            echo "\" class=\"dropdown-item\"> Vous êtes une entreprise ? </a>
          <a href=\"";
            // line 36
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_register", ["typeUser" => "coiffeurs"]);
            echo "\" class=\"dropdown-item\"> Vous êtes un coiffeur ?</a>
        </div>
      </li>
      <li class=\"nav-item active\">
        <a class=\"btn btn-dark\" href=\"";
            // line 40
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_login");
            echo "\">Connexion</a>
      </li>
    </ul>
    ";
        } else {
            // line 44
            echo "      ";
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_COIFFEURS")) {
                // line 45
                echo "      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
        <li class=\"nav-item active\">
          <a href=\"";
                // line 47
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("coiffeur.devis.index");
                echo "\" class=\"nav-link\">Tableau de bord</a>
        </li>
        <li class=\"nav-item active\">
          <div class=\"nav-link\">|</div>
        </li>
        <li class=\"nav-item active\">
          <a href=\"";
                // line 53
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("coiffeur.profil.index", ["coiffeur" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 53, $this->source); })()), "user", [], "any", false, false, false, 53), "id", [], "any", false, false, false, 53)]), "html", null, true);
                echo "\" class=\"nav-link\">Mon profil</a>
        </li>
      </ul>
      ";
            }
            // line 57
            echo "      ";
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMINS")) {
                // line 58
                echo "      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
        <li class=\"nav-item active\">
          <a href=\"";
                // line 60
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizandcut.users.index");
                echo "\" class=\"nav-link\">Gestion des utilisateurs</a>
        </li>
        <li class=\"nav-item active\">
          <div class=\"nav-link\">|</div>
        </li>
        <li class=\"nav-item active\">
          <a href=\"";
                // line 66
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizandcut.propositions.index");
                echo "\" class=\"nav-link\">Voir les propositions</a>
        </li>
        <li class=\"nav-item active\">
          <div class=\"nav-link\">|</div>
        </li>
        <li class=\"nav-item active\">
        <a href=\"\" class=\"nav-link\">Boite de reception</a>
        </li>
      </ul>
      ";
            }
            // line 76
            echo "      ";
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ENTREPRISES")) {
                // line 77
                echo "      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
            <li class=\"nav-item active\">
              <a href=\"";
                // line 79
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.devis.index");
                echo "\" class=\"nav-link\">Tableau de bord</a>
            </li>
            <li class=\"nav-item active\">
              <div class=\"nav-link\">|</div>
            </li>
            <li class=\"nav-item active\">
              <a href=\"";
                // line 85
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.devis.form");
                echo "\" class=\"nav-link\">Créer un événement</a>
            </li>
      </ul>
      ";
            }
            // line 89
            echo "      <ul class=\"navbar-nav justify-content-end\">
        <li class=\"nav-item active\">
          <div class=\"nav-link\" href=\"\">Bienvenue ";
            // line 91
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 91, $this->source); })()), "user", [], "any", false, false, false, 91), "prenom", [], "any", false, false, false, 91), "html", null, true);
            echo "</div>
        </li>
        <li class=\"nav-item active\">
          <a class=\"btn btn-danger\" href=\"";
            // line 94
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_logout");
            echo "\">Déconnexion</a>
        </li>
      </ul>
    ";
        }
        // line 98
        echo "  </div>
</nav>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "_inc/nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 98,  203 => 94,  197 => 91,  193 => 89,  186 => 85,  177 => 79,  173 => 77,  170 => 76,  157 => 66,  148 => 60,  144 => 58,  141 => 57,  134 => 53,  125 => 47,  121 => 45,  118 => 44,  111 => 40,  104 => 36,  100 => 35,  91 => 29,  84 => 25,  80 => 24,  71 => 18,  67 => 16,  65 => 15,  55 => 8,  51 => 7,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo01\" aria-controls=\"navbarTogglerDemo01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>
  <div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo01\">
    <!--a class=\"navbar-brand\" >Biz&Cut</a-->
    <a  href=\"{{ url('homepage.index') }}\">
      <img src=\"{{ asset('img/logo_blanc.png') }}\" width=\"150\" class=\"img-fluid\"/>
    </a>
    <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
      <li class=\"nav-item active\">
      </li>
    </ul>

    {% if not is_granted('IS_AUTHENTICATED_FULLY') %}
    <ul class=\"navbar-nav justify-content-end\">
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"{{url('bizAndCutOtherPage.prestationDeCoiffure.index')}}\">Prestation de coiffure sur votre lieu de travail</a>
      </li>
      <li class=\"nav-item dropdown\">
        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
          Comment ça marche ? </a>
        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdownMenuLink\">\t
          <a href=\"{{url('bizAndCutOtherPage.commentCaMarche.index')}}\" class=\"dropdown-item\"> Pour les entreprises </a>
          <a href=\"{{url('bizAndCutOtherPage.commentCaMarche.indexCoiffeur')}}\" class=\"dropdown-item\"> Pour les coiffeurs </a>
        </div>
      </li>
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"{{url('bizAndCutOtherPage.detailsDeNosPrestation.index')}}\">Nos prestations</a>
      </li>
      <li class=\"nav-item dropdown\">
        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"navbarDropdownMenuLink\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
          Inscription </a>
        <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdownMenuLink\">\t
          <a href=\"{{ url('app_register', { typeUser:'entreprises' }) }}\" class=\"dropdown-item\"> Vous êtes une entreprise ? </a>
          <a href=\"{{ url('app_register', { typeUser:'coiffeurs' }) }}\" class=\"dropdown-item\"> Vous êtes un coiffeur ?</a>
        </div>
      </li>
      <li class=\"nav-item active\">
        <a class=\"btn btn-dark\" href=\"{{ url('app_login') }}\">Connexion</a>
      </li>
    </ul>
    {% else %}
      {% if is_granted('ROLE_COIFFEURS') %}
      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
        <li class=\"nav-item active\">
          <a href=\"{{ url('coiffeur.devis.index') }}\" class=\"nav-link\">Tableau de bord</a>
        </li>
        <li class=\"nav-item active\">
          <div class=\"nav-link\">|</div>
        </li>
        <li class=\"nav-item active\">
          <a href=\"{{ url('coiffeur.profil.index',  { coiffeur:app.user.id}) }}\" class=\"nav-link\">Mon profil</a>
        </li>
      </ul>
      {% endif %}
      {% if is_granted('ROLE_ADMINS') %}
      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
        <li class=\"nav-item active\">
          <a href=\"{{ url('bizandcut.users.index') }}\" class=\"nav-link\">Gestion des utilisateurs</a>
        </li>
        <li class=\"nav-item active\">
          <div class=\"nav-link\">|</div>
        </li>
        <li class=\"nav-item active\">
          <a href=\"{{ url('bizandcut.propositions.index') }}\" class=\"nav-link\">Voir les propositions</a>
        </li>
        <li class=\"nav-item active\">
          <div class=\"nav-link\">|</div>
        </li>
        <li class=\"nav-item active\">
        <a href=\"\" class=\"nav-link\">Boite de reception</a>
        </li>
      </ul>
      {% endif %}
      {% if is_granted('ROLE_ENTREPRISES') %}
      <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
            <li class=\"nav-item active\">
              <a href=\"{{ url('entreprise.devis.index') }}\" class=\"nav-link\">Tableau de bord</a>
            </li>
            <li class=\"nav-item active\">
              <div class=\"nav-link\">|</div>
            </li>
            <li class=\"nav-item active\">
              <a href=\"{{ url('entreprise.devis.form') }}\" class=\"nav-link\">Créer un événement</a>
            </li>
      </ul>
      {% endif %}
      <ul class=\"navbar-nav justify-content-end\">
        <li class=\"nav-item active\">
          <div class=\"nav-link\" href=\"\">Bienvenue {{ app.user.prenom }}</div>
        </li>
        <li class=\"nav-item active\">
          <a class=\"btn btn-danger\" href=\"{{ url('app_logout') }}\">Déconnexion</a>
        </li>
      </ul>
    {% endif %}
  </div>
</nav>", "_inc/nav.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\_inc\\nav.html.twig");
    }
}
