<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entreprise/devis/form.html.twig */
class __TwigTemplate_95b57090d053a3830bef701ed2847d9550b340c2c9cef815a34b9353a8b4f154 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "entreprise/devis/form.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "entreprise/devis/form.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "entreprise/devis/form.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Créer un événement</h1>
\t\t\t
\t\t\t";
        // line 7
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 7, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        // line 13
        echo "
\t\t\t
\t\t\t<p>
\t\t\t\t";
        // line 16
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 16, $this->source); })()), "libelle", [], "any", false, false, false, 16), 'label', ["label" => "Nom de l'evenement"]);
        echo "
\t\t\t\t";
        // line 17
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 17, $this->source); })()), "libelle", [], "any", false, false, false, 17), 'widget', ["attr" => ["autofocus" => "autofocus"]]);
        // line 22
        echo "
\t\t\t</p>
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t";
        // line 26
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 26, $this->source); })()), "date", [], "any", false, false, false, 26), 'label', ["label" => "Date de l'evenement "]);
        echo " 
\t\t\t\t\t";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 27, $this->source); })()), "date", [], "any", false, false, false, 27), 'widget', ["attr" => ["placeholder" => "Saisissez un date"]]);
        // line 30
        echo "
\t\t\t\t</div>
\t\t\t\t
\t\t\t\t<div class=\"col-md-3\">
\t\t\t\t\t";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })()), "heureDebut", [], "any", false, false, false, 34), 'label', ["label" => "Debut de l'evenement "]);
        echo " 
\t\t\t\t\t";
        // line 35
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 35, $this->source); })()), "heureDebut", [], "any", false, false, false, 35), 'widget', ["attr" => ["placeholder" => "Saisissez une heure de debut"]]);
        // line 38
        echo "
\t\t\t\t</div>
\t\t\t\t
\t\t\t\t<div class=\"col-md-3\">
\t\t\t\t\t";
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 42, $this->source); })()), "heureFin", [], "any", false, false, false, 42), 'label', ["label" => "Fin de l'evenement "]);
        echo " 
\t\t\t\t\t";
        // line 43
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 43, $this->source); })()), "heureFin", [], "any", false, false, false, 43), 'widget', ["attr" => ["placeholder" => "Saisissez une heure de fin"]]);
        // line 46
        echo "
\t\t\t\t</div>
\t\t\t</div >
\t\t\t
\t\t\t<div class=\"row\">
\t\t\t</div >
\t\t\t<p>
\t\t\t\t</br>
\t\t\t\t<input type=\"submit\" value=\"Valider\" class=\"btn btn-dark\"/>
\t\t\t</p>
\t\t\t";
        // line 56
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 56, $this->source); })()), 'form_end');
        echo "
\t\t</div>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "entreprise/devis/form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 56,  123 => 46,  121 => 43,  117 => 42,  111 => 38,  109 => 35,  105 => 34,  99 => 30,  97 => 27,  93 => 26,  87 => 22,  85 => 17,  81 => 16,  76 => 13,  74 => 7,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Créer un événement</h1>
\t\t\t
\t\t\t{{form_start(form,
                    { attr: 
                        {
                            novalidate:'novalidate'
                        } 
                    })
            }}
\t\t\t
\t\t\t<p>
\t\t\t\t{{form_label(form.libelle, \"Nom de l'evenement\")}}
\t\t\t\t{{form_widget(form.libelle,
                    { attr: 
                        {
\t\t\t\t\t\t\tautofocus:'autofocus'
\t\t\t\t\t\t}
                    })}}
\t\t\t</p>
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t{{ form_label(form.date, \"Date de l'evenement \") }} 
\t\t\t\t\t{{form_widget(form.date,
\t\t\t\t\t{ attr: 
\t\t\t\t\t\t{placeholder:'Saisissez un date'} 
\t\t\t\t\t})}}
\t\t\t\t</div>
\t\t\t\t
\t\t\t\t<div class=\"col-md-3\">
\t\t\t\t\t{{ form_label(form.heureDebut, \"Debut de l'evenement \") }} 
\t\t\t\t\t{{form_widget(form.heureDebut,
\t\t\t\t\t{ attr: 
\t\t\t\t\t\t{placeholder:'Saisissez une heure de debut'} 
\t\t\t\t\t})}}
\t\t\t\t</div>
\t\t\t\t
\t\t\t\t<div class=\"col-md-3\">
\t\t\t\t\t{{ form_label(form.heureFin, \"Fin de l'evenement \") }} 
\t\t\t\t\t{{form_widget(form.heureFin,
\t\t\t\t\t{ attr: 
\t\t\t\t\t\t{placeholder:'Saisissez une heure de fin'} 
\t\t\t\t\t})}}
\t\t\t\t</div>
\t\t\t</div >
\t\t\t
\t\t\t<div class=\"row\">
\t\t\t</div >
\t\t\t<p>
\t\t\t\t</br>
\t\t\t\t<input type=\"submit\" value=\"Valider\" class=\"btn btn-dark\"/>
\t\t\t</p>
\t\t\t{{form_end(form)}}
\t\t</div>
\t</div>
{% endblock %}", "entreprise/devis/form.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\entreprise\\devis\\form.html.twig");
    }
}
