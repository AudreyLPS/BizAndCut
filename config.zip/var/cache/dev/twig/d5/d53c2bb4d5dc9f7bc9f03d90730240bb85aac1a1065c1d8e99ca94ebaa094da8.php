<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _inc/navCoiffeur.html.twig */
class __TwigTemplate_d17f4d15bf3e6da5ffe1bf55b1386502e7c700b892173f483d60d81c9f0a57f1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/navCoiffeur.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_inc/navCoiffeur.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo01\" aria-controls=\"navbarTogglerDemo01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>
  <div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo01\">
    <a class=\"navbar-brand\" href=\"";
        // line 6
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("homepage.index");
        echo "\">Biz&Cut</a>
    <img class=\"fit-picture\" src=\"/public/img/logo.png\" alt=\"logo\">
    <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"";
        // line 10
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("homepage.index");
        echo "\">Home <span class=\"sr-only\">(current)</span></a>
      </li>

      </ul>
    ";
        // line 14
        if ( !$this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 15
            echo "    <ul class=\"navbar-nav justify-content-end\">
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"\">Comment ça marche ?</a>
      </li>
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"";
            // line 20
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_register", ["typeUser" => "coiffeurs"]);
            echo "\">Inscription Coiffeur</a>
      </li>
      <li class=\"nav-item active\">
        <a class=\"btn btn-success\" href=\"";
            // line 23
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_login");
            echo "\">Connexion</a>
      </li>
    </ul>
    ";
        } else {
            // line 27
            echo "    <ul class=\"navbar-nav justify-content-end\">
      <li class=\"nav-item active\">
        <div class=\"nav-link\" href=\"\">Bienvenue ";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 29, $this->source); })()), "user", [], "any", false, false, false, 29), "prenom", [], "any", false, false, false, 29), "html", null, true);
            echo "</div>
      </li>
      <li class=\"nav-item active\">
        <a class=\"btn btn-danger\" href=\"";
            // line 32
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_logout");
            echo "\">Déconnexion</a>
      </li>
    </ul>
    ";
        }
        // line 36
        echo "  </div>
</nav>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "_inc/navCoiffeur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 36,  96 => 32,  90 => 29,  86 => 27,  79 => 23,  73 => 20,  66 => 15,  64 => 14,  57 => 10,  50 => 6,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarTogglerDemo01\" aria-controls=\"navbarTogglerDemo01\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
    <span class=\"navbar-toggler-icon\"></span>
  </button>
  <div class=\"collapse navbar-collapse\" id=\"navbarTogglerDemo01\">
    <a class=\"navbar-brand\" href=\"{{ url('homepage.index') }}\">Biz&Cut</a>
    <img class=\"fit-picture\" src=\"/public/img/logo.png\" alt=\"logo\">
    <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"{{ url('homepage.index') }}\">Home <span class=\"sr-only\">(current)</span></a>
      </li>

      </ul>
    {% if not is_granted('IS_AUTHENTICATED_FULLY') %}
    <ul class=\"navbar-nav justify-content-end\">
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"\">Comment ça marche ?</a>
      </li>
      <li class=\"nav-item active\">
        <a class=\"nav-link\" href=\"{{ url('app_register', { typeUser:'coiffeurs' }) }}\">Inscription Coiffeur</a>
      </li>
      <li class=\"nav-item active\">
        <a class=\"btn btn-success\" href=\"{{ url('app_login') }}\">Connexion</a>
      </li>
    </ul>
    {% else %}
    <ul class=\"navbar-nav justify-content-end\">
      <li class=\"nav-item active\">
        <div class=\"nav-link\" href=\"\">Bienvenue {{ app.user.prenom }}</div>
      </li>
      <li class=\"nav-item active\">
        <a class=\"btn btn-danger\" href=\"{{ url('app_logout') }}\">Déconnexion</a>
      </li>
    </ul>
    {% endif %}
  </div>
</nav>", "_inc/navCoiffeur.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\_inc\\navCoiffeur.html.twig");
    }
}
