<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* bizandcut/propositions/index.html.twig */
class __TwigTemplate_a560984a63b5c21e23f7651bf184af75bcb37d3b6f622dbbfe7a0f4c80fbee3a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bizandcut/propositions/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bizandcut/propositions/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "bizandcut/propositions/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t";
        // line 6
        $this->loadTemplate("_inc/flash.messages.html.twig", "bizandcut/propositions/index.html.twig", 6)->display($context);
        // line 7
        echo "\t\t\t<h1>Liste des propositions</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Evénement</th>
\t\t\t\t<th>Fait par</th>
\t\t\t\t<th>Fait le</th>
\t\t\t\t<th>Durée</th>
\t\t\t\t<th>Nb participant</th>
\t\t\t\t<th>Montant</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 27, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["proposition"]) {
            echo " 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 29), "libelle", [], "any", false, false, false, 29), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "coiffeur", [], "any", false, false, false, 30), "nom", [], "any", false, false, false, 30), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 31
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "dateProposition", [], "any", false, false, false, 31), "m/d/Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">
\t\t\t\t\t\t";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 33), "heureDebut", [], "any", false, false, false, 33), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 33), "heureFin", [], "any", false, false, false, 33), "html", null, true);
            echo "
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 35), "nbParticipants", [], "any", false, false, false, 35), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "montant", [], "any", false, false, false, 36), "html", null, true);
            echo "€</td>
\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t\t";
            // line 38
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["proposition"], "validationBC", [], "any", false, false, false, 38), 1)) {
                // line 39
                echo "\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizandcut.propositions.accepte", ["id" => twig_get_attribute($this->env, $this->source, $context["proposition"], "id", [], "any", false, false, false, 39), "idDevis" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 39), "id", [], "any", false, false, false, 39)]), "html", null, true);
                echo "\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: green;\"></div></a>
\t\t\t\t\t\t";
            } else {
                // line 41
                echo "\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizandcut.propositions.accepte", ["id" => twig_get_attribute($this->env, $this->source, $context["proposition"], "id", [], "any", false, false, false, 41), "idDevis" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["proposition"], "devis", [], "any", false, false, false, 41), "id", [], "any", false, false, false, 41)]), "html", null, true);
                echo "\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: red;\"></div></a>
\t\t\t\t\t\t";
            }
            // line 43
            echo "\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['proposition'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "\t\t</table>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bizandcut/propositions/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 46,  146 => 43,  140 => 41,  134 => 39,  132 => 38,  127 => 36,  123 => 35,  116 => 33,  111 => 31,  107 => 30,  103 => 29,  96 => 27,  74 => 7,  72 => 6,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t{% include \"_inc/flash.messages.html.twig\" %}
\t\t\t<h1>Liste des propositions</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Evénement</th>
\t\t\t\t<th>Fait par</th>
\t\t\t\t<th>Fait le</th>
\t\t\t\t<th>Durée</th>
\t\t\t\t<th>Nb participant</th>
\t\t\t\t<th>Montant</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t{% for proposition in results %} 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">{{ proposition.devis.libelle }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.coiffeur.nom }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.dateProposition|date(\"m/d/Y\") }}</td>
\t\t\t\t\t<td class=\"col-md-2\">
\t\t\t\t\t\t{{ proposition.devis.heureDebut }} - {{ proposition.devis.heureFin }}
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.devis.nbParticipants}}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.montant }}€</td>
\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t\t{% if proposition.validationBC == 1  %}
\t\t\t\t\t\t\t<a href=\"{{ url('bizandcut.propositions.accepte', { id:proposition.id, idDevis:proposition.devis.id }) }}\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: green;\"></div></a>
\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t<a href=\"{{ url('bizandcut.propositions.accepte', { id:proposition.id, idDevis:proposition.devis.id }) }}\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: red;\"></div></a>
\t\t\t\t\t\t{% endif %}
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t{% endfor %}
\t\t</table>
\t</div>
{% endblock %}









", "bizandcut/propositions/index.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\bizandcut\\propositions\\index.html.twig");
    }
}
