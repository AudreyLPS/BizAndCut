<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* bizandcut/users/index.html.twig */
class __TwigTemplate_af64580064da2ca82e35bcec55dcf9e796797531f2971dd54a09289aef5bb557 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bizandcut/users/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bizandcut/users/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "bizandcut/users/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col-md-8\">
\t\t\t<h1>Gestion des utilisateurs</h1> 
\t\t\t";
        // line 7
        $this->loadTemplate("_inc/flash.messages.html.twig", "bizandcut/users/index.html.twig", 7)->display($context);
        // line 8
        echo "\t\t</div>
\t\t<div class=\"col-md-4\">
\t\t<p>
\t\t\t";
        // line 11
        $this->loadTemplate("_inc/search.html.twig", "bizandcut/users/index.html.twig", 11)->display(twig_to_array(["form" => (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 11, $this->source); })())]));
        // line 12
        echo "\t\t</p>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t\t<div class=\"col-md-12\">
\t\t\t
\t\t\t\t<div class=\"row\">
\t\t\t\t\t";
        // line 19
        $context["nbCoif"] = 0;
        // line 20
        echo "\t\t\t\t\t";
        $context["nbEnt"] = 0;
        // line 21
        echo "\t\t\t\t\t";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 21, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            echo " 
\t\t\t\t\t\t";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["user"], "roles", [], "any", false, false, false, 22));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                // line 23
                echo "\t\t\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t\t\t\t";
                // line 24
                if (0 === twig_compare($context["role"], "ROLE_COIFFEURS")) {
                    echo " ";
                    $context["nbCoif"] = ((isset($context["nbCoif"]) || array_key_exists("nbCoif", $context) ? $context["nbCoif"] : (function () { throw new RuntimeError('Variable "nbCoif" does not exist.', 24, $this->source); })()) + 1);
                    echo "  ";
                }
                // line 25
                echo "\t\t\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_ENTREPRISES")) {
                    echo " ";
                    $context["nbEnt"] = ((isset($context["nbEnt"]) || array_key_exists("nbEnt", $context) ? $context["nbEnt"] : (function () { throw new RuntimeError('Variable "nbEnt" does not exist.', 25, $this->source); })()) + 1);
                    echo "  ";
                }
                // line 26
                echo "\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo " 
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo " 
\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\tIl y a ";
        // line 30
        echo twig_escape_filter($this->env, (isset($context["nbCoif"]) || array_key_exists("nbCoif", $context) ? $context["nbCoif"] : (function () { throw new RuntimeError('Variable "nbCoif" does not exist.', 30, $this->source); })()), "html", null, true);
        echo " coiffeur(s) dans la base de données.
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\tIl y a ";
        // line 33
        echo twig_escape_filter($this->env, (isset($context["nbEnt"]) || array_key_exists("nbEnt", $context) ? $context["nbEnt"] : (function () { throw new RuntimeError('Variable "nbEnt" does not exist.', 33, $this->source); })()), "html", null, true);
        echo " entreprise(s) dans la base de données.
\t\t\t\t\t</div>
\t\t\t\t</div></br>
\t\t\t
\t\t</div>
\t</div>
\t<div class=\"row\" >\t\t
\t\t<div class=\"col-md-4\">
\t\t\t<a href=\"";
        // line 41
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_register", ["typeUser" => "entreprises"]);
        echo "\" class=\"btn btn-dark col-md-10\">+ Ajouter une entreprise</a>
\t\t</div>
\t\t\t\t
\t\t<div class=\"col-md-4\">
\t\t\t<a href=\"";
        // line 45
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_register", ["typeUser" => "admins"]);
        echo "\" class=\"btn btn-dark col-md-10\">+ Ajouter un administrateur</a>
\t\t</div>
\t\t\t\t
\t\t<div class=\"col-md-4\">
\t\t\t<a href=\"";
        // line 49
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("app_register", ["typeUser" => "coiffeurs"]);
        echo "\" class=\"btn btn-dark col-md-10\">+ Ajouter un coiffeur</a>
\t\t</div>
\t\t
\t</div></br>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Email</th>
\t\t\t\t<th>Nom</th>
\t\t\t\t<th>Prénom</th>
\t\t\t\t<th>Rôle</th>
\t\t\t\t<th>Statut</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t";
        // line 62
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 62, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            echo " 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">";
            // line 64
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "email", [], "any", false, false, false, 64), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 65
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "nom", [], "any", false, false, false, 65), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 66
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "prenom", [], "any", false, false, false, 66), "html", null, true);
            echo "</td>
\t\t\t\t\t";
            // line 67
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["user"], "roles", [], "any", false, false, false, 67));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                // line 68
                echo "\t\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t\t\t";
                // line 69
                if (0 === twig_compare($context["role"], "ROLE_COIFFEURS")) {
                    echo " Coiffeur  ";
                }
                // line 70
                echo "\t\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_ADMINS")) {
                    echo " Administrateur  ";
                }
                // line 71
                echo "\t\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_SALARIES")) {
                    echo " Salarié  ";
                }
                // line 72
                echo "\t\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_ENTREPRISES")) {
                    echo " Entreprise  ";
                }
                // line 73
                echo "\t\t\t\t\t\t</td>
\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 74
            echo " 
\t\t\t\t\t
\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t";
            // line 77
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["user"], "deleted", [], "any", false, false, false, 77), 0)) {
                // line 78
                echo "\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizandcut.users.desactive", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 78)]), "html", null, true);
                echo "\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: green;\"></div></a>
\t\t\t\t\t";
            } else {
                // line 80
                echo "\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizandcut.users.active", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 80)]), "html", null, true);
                echo "\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: red;\"></div></a>
\t\t\t\t\t";
            }
            // line 81
            echo " 
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t";
            // line 84
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["user"], "roles", [], "any", false, false, false, 84));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                // line 85
                echo "\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_COIFFEURS")) {
                    echo " 
\t\t\t\t\t\t\t\t<a href=\"";
                    // line 86
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("bizandcut.profil.index", ["coiffeur" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 86)]), "html", null, true);
                    echo "\" class=\"btn btn-dark col-md-4\">Profil</a>
\t\t\t\t\t\t\t\t<a href=\"\" class=\"btn btn-dark col-md-4\">Valider</a>
\t\t\t\t\t\t";
                }
                // line 89
                echo "\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_ADMINS")) {
                }
                // line 90
                echo "\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_SALARIES")) {
                }
                // line 91
                echo "\t\t\t\t\t\t";
                if (0 === twig_compare($context["role"], "ROLE_ENTREPRISES")) {
                }
                // line 92
                echo "\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo " 
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "\t\t</table>
\t\t
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bizandcut/users/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  305 => 96,  291 => 92,  287 => 91,  283 => 90,  279 => 89,  273 => 86,  268 => 85,  264 => 84,  259 => 81,  253 => 80,  247 => 78,  245 => 77,  240 => 74,  233 => 73,  228 => 72,  223 => 71,  218 => 70,  214 => 69,  211 => 68,  207 => 67,  203 => 66,  199 => 65,  195 => 64,  188 => 62,  172 => 49,  165 => 45,  158 => 41,  147 => 33,  141 => 30,  137 => 28,  130 => 27,  123 => 26,  116 => 25,  110 => 24,  107 => 23,  103 => 22,  96 => 21,  93 => 20,  91 => 19,  82 => 12,  80 => 11,  75 => 8,  73 => 7,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col-md-8\">
\t\t\t<h1>Gestion des utilisateurs</h1> 
\t\t\t{% include \"_inc/flash.messages.html.twig\" %}
\t\t</div>
\t\t<div class=\"col-md-4\">
\t\t<p>
\t\t\t{% include \"_inc/search.html.twig\" with {form: form} only %}
\t\t</p>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t\t<div class=\"col-md-12\">
\t\t\t
\t\t\t\t<div class=\"row\">
\t\t\t\t\t{% set nbCoif = 0 %}
\t\t\t\t\t{% set nbEnt = 0 %}
\t\t\t\t\t{% for user in results %} 
\t\t\t\t\t\t{% for role in user.roles %}
\t\t\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t\t\t\t{% if role == 'ROLE_COIFFEURS' %} {% set nbCoif = nbCoif + 1 %}  {% endif %}
\t\t\t\t\t\t\t\t{% if role == 'ROLE_ENTREPRISES' %} {% set nbEnt = nbEnt + 1 %}  {% endif %}
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t{% endfor %} 
\t\t\t\t\t{% endfor %} 
\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\tIl y a {{ nbCoif }} coiffeur(s) dans la base de données.
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\tIl y a {{ nbEnt }} entreprise(s) dans la base de données.
\t\t\t\t\t</div>
\t\t\t\t</div></br>
\t\t\t
\t\t</div>
\t</div>
\t<div class=\"row\" >\t\t
\t\t<div class=\"col-md-4\">
\t\t\t<a href=\"{{ url('app_register', { typeUser:'entreprises' }) }}\" class=\"btn btn-dark col-md-10\">+ Ajouter une entreprise</a>
\t\t</div>
\t\t\t\t
\t\t<div class=\"col-md-4\">
\t\t\t<a href=\"{{ url('app_register', { typeUser:'admins' }) }}\" class=\"btn btn-dark col-md-10\">+ Ajouter un administrateur</a>
\t\t</div>
\t\t\t\t
\t\t<div class=\"col-md-4\">
\t\t\t<a href=\"{{ url('app_register', { typeUser:'coiffeurs' }) }}\" class=\"btn btn-dark col-md-10\">+ Ajouter un coiffeur</a>
\t\t</div>
\t\t
\t</div></br>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Email</th>
\t\t\t\t<th>Nom</th>
\t\t\t\t<th>Prénom</th>
\t\t\t\t<th>Rôle</th>
\t\t\t\t<th>Statut</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t{% for user in results %} 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">{{ user.email }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ user.nom }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ user.prenom }}</td>
\t\t\t\t\t{% for role in user.roles %}
\t\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t\t\t{% if role == 'ROLE_COIFFEURS' %} Coiffeur  {% endif %}
\t\t\t\t\t\t\t{% if role == 'ROLE_ADMINS' %} Administrateur  {% endif %}
\t\t\t\t\t\t\t{% if role == 'ROLE_SALARIES' %} Salarié  {% endif %}
\t\t\t\t\t\t\t{% if role == 'ROLE_ENTREPRISES' %} Entreprise  {% endif %}
\t\t\t\t\t\t</td>
\t\t\t\t\t{% endfor %} 
\t\t\t\t\t
\t\t\t\t\t<td class=\"col-md-1\">
\t\t\t\t\t{% if user.deleted == 0  %}
\t\t\t\t\t\t<a href=\"{{ url('bizandcut.users.desactive', { id:user.id}) }}\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: green;\"></div></a>
\t\t\t\t\t{% else %}
\t\t\t\t\t\t<a href=\"{{ url('bizandcut.users.active', { id:user.id}) }}\"><div style=\"width: 40px; height: 40px; border-radius: 20px; background: red;\"></div></a>
\t\t\t\t\t{% endif %} 
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t{% for role in user.roles %}
\t\t\t\t\t\t{% if role == 'ROLE_COIFFEURS' %} 
\t\t\t\t\t\t\t\t<a href=\"{{ url('bizandcut.profil.index', { coiffeur:user.id}) }}\" class=\"btn btn-dark col-md-4\">Profil</a>
\t\t\t\t\t\t\t\t<a href=\"\" class=\"btn btn-dark col-md-4\">Valider</a>
\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t{% if role == 'ROLE_ADMINS' %}{% endif %}
\t\t\t\t\t\t{% if role == 'ROLE_SALARIES' %}{% endif %}
\t\t\t\t\t\t{% if role == 'ROLE_ENTREPRISES' %}{% endif %}
\t\t\t\t\t{% endfor %} 
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t{% endfor %}
\t\t</table>
\t\t
\t</div>
{% endblock %}

", "bizandcut/users/index.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\bizandcut\\users\\index.html.twig");
    }
}
