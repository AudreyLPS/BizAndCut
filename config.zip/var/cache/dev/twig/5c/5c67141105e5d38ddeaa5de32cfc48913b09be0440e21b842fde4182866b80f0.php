<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* coiffeur/profil/index.html.twig */
class __TwigTemplate_41667c0348faf202a27d54268ff8d2c3d198e5b1e177046405b4d39020c71743 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "coiffeur/profil/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "coiffeur/profil/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "coiffeur/profil/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t";
        // line 6
        $this->loadTemplate("_inc/flash.messages.html.twig", "coiffeur/profil/index.html.twig", 6)->display($context);
        // line 7
        echo "\t\t\t<h1> Profil </h1>
\t\t</div>
\t</div>

\t
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t
\t\t<table class=\"table table-striped\">
\t\t\t<ul>
\t\t\t\t<li> 
\t\t\t\t\t<b> Civilite : </b> 
\t\t\t\t\t";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 24, $this->source); })()), "civilite", [], "any", false, false, false, 24), "html", null, true);
        echo "
\t\t\t\t\t\t
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Nom: </b> 
\t\t\t\t\t";
        // line 29
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 29, $this->source); })()), "nom", [], "any", false, false, false, 29), "html", null, true);
        echo "
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Prénom: </b>
\t\t\t\t\t";
        // line 33
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 33, $this->source); })()), "prenom", [], "any", false, false, false, 33), "html", null, true);
        echo " 
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Adresse: </b>
\t\t\t\t\t";
        // line 37
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 37, $this->source); })()), "adresse", [], "any", false, false, false, 37), "html", null, true);
        echo "
\t\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Ville: </b>
\t\t\t\t\t";
        // line 41
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 41, $this->source); })()), "ville", [], "any", false, false, false, 41), "html", null, true);
        echo "
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Code postal: </b>
\t\t\t\t\t";
        // line 45
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 45, $this->source); })()), "cp", [], "any", false, false, false, 45), "html", null, true);
        echo "
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Téléphone: </b>
\t\t\t\t\t";
        // line 49
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 49, $this->source); })()), "telephone", [], "any", false, false, false, 49), "html", null, true);
        echo "
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Email: </b>
\t\t\t\t\t";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 53, $this->source); })()), "email", [], "any", false, false, false, 53), "html", null, true);
        echo "
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Nombre d'année d'expérience: </b>
\t\t\t\t\t";
        // line 57
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 57, $this->source); })()), "nbAnneesExp", [], "any", false, false, false, 57), "html", null, true);
        echo "
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Distance entre votre adresse souhaitée et l'adresse de l'entreprise: </b>
\t\t\t\t\t";
        // line 61
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 61, $this->source); })()), "distance", [], "any", false, false, false, 61), "html", null, true);
        echo "
\t\t\t\t</li>
\t\t\t\t
\t\t\t\t";
        // line 64
        if (0 !== twig_compare((isset($context["profil"]) || array_key_exists("profil", $context) ? $context["profil"] : (function () { throw new RuntimeError('Variable "profil" does not exist.', 64, $this->source); })()), null)) {
            // line 65
            echo "\t\t\t\t\t<li> 
\t\t\t\t\t\t<b> RIB: </b>
\t\t\t\t\t\t";
            // line 67
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profil"]) || array_key_exists("profil", $context) ? $context["profil"] : (function () { throw new RuntimeError('Variable "profil" does not exist.', 67, $this->source); })()), "rib", [], "any", false, false, false, 67), "html", null, true);
            echo "
\t\t\t\t\t</li>
\t\t\t\t\t<li> 
\t\t\t\t\t\t<b> Saisissez votre diplôme: </b>
\t\t\t\t\t\t";
            // line 71
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["profil"]) || array_key_exists("profil", $context) ? $context["profil"] : (function () { throw new RuntimeError('Variable "profil" does not exist.', 71, $this->source); })()), "diplome", [], "any", false, false, false, 71), "html", null, true);
            echo "
\t\t\t\t\t</li>
\t\t\t<a href=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("coiffeur.profil.form.update", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["profil"]) || array_key_exists("profil", $context) ? $context["profil"] : (function () { throw new RuntimeError('Variable "profil" does not exist.', 73, $this->source); })()), "id", [], "any", false, false, false, 73)]), "html", null, true);
            echo "\" class=\"btn btn-info\">Complétez votre profil</a>
\t\t\t\t";
        } else {
            // line 75
            echo "\t\t\t\t\t<a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("coiffeur.profil.form");
            echo "\" class=\"btn btn-info\">Complétez votre profil</a>
\t\t\t\t";
        }
        // line 77
        echo "\t\t\t</ul>

\t\t</table>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "coiffeur/profil/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  192 => 77,  186 => 75,  181 => 73,  176 => 71,  169 => 67,  165 => 65,  163 => 64,  157 => 61,  150 => 57,  143 => 53,  136 => 49,  129 => 45,  122 => 41,  115 => 37,  108 => 33,  101 => 29,  93 => 24,  74 => 7,  72 => 6,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t{% include \"_inc/flash.messages.html.twig\" %}
\t\t\t<h1> Profil </h1>
\t\t</div>
\t</div>

\t
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t
\t\t<table class=\"table table-striped\">
\t\t\t<ul>
\t\t\t\t<li> 
\t\t\t\t\t<b> Civilite : </b> 
\t\t\t\t\t{{user.civilite}}
\t\t\t\t\t\t
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Nom: </b> 
\t\t\t\t\t{{user.nom}}
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Prénom: </b>
\t\t\t\t\t{{user.prenom}} 
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Adresse: </b>
\t\t\t\t\t{{user.adresse}}
\t\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Ville: </b>
\t\t\t\t\t{{user.ville}}
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Code postal: </b>
\t\t\t\t\t{{user.cp}}
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Téléphone: </b>
\t\t\t\t\t{{user.telephone}}
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Email: </b>
\t\t\t\t\t{{user.email}}
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Nombre d'année d'expérience: </b>
\t\t\t\t\t{{user.nbAnneesExp}}
\t\t\t\t</li>
\t\t\t\t<li> 
\t\t\t\t\t<b> Distance entre votre adresse souhaitée et l'adresse de l'entreprise: </b>
\t\t\t\t\t{{user.distance}}
\t\t\t\t</li>
\t\t\t\t
\t\t\t\t{% if profil != null %}
\t\t\t\t\t<li> 
\t\t\t\t\t\t<b> RIB: </b>
\t\t\t\t\t\t{{profil.rib}}
\t\t\t\t\t</li>
\t\t\t\t\t<li> 
\t\t\t\t\t\t<b> Saisissez votre diplôme: </b>
\t\t\t\t\t\t{{profil.diplome}}
\t\t\t\t\t</li>
\t\t\t<a href=\"{{ url('coiffeur.profil.form.update', {id:profil.id}) }}\" class=\"btn btn-info\">Complétez votre profil</a>
\t\t\t\t{% else %}
\t\t\t\t\t<a href=\"{{ url('coiffeur.profil.form') }}\" class=\"btn btn-info\">Complétez votre profil</a>
\t\t\t\t{% endif %}
\t\t\t</ul>

\t\t</table>
\t</div>
{% endblock %}









", "coiffeur/profil/index.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\coiffeur\\profil\\index.html.twig");
    }
}
