<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* insc_entre/form.html.twig */
class __TwigTemplate_dd5ecd85534ad4310035e44e888d69ea37b565afa68fe9a85ae890b73a4c8c72 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "insc_entre/form.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "insc_entre/form.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "insc_entre/form.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Création Compte Entreprise</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t";
        // line 12
        echo "\t\t\t";
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 12, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
\t\t\t\t<p>
\t\t\t\t\t";
        // line 15
        echo "\t\t\t\t\t";
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 15, $this->source); })()), "nom_entreprise", [], "any", false, false, false, 15), 'label', ["label" => "Nom Entreprise:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 17
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 17, $this->source); })()), "nom_entreprise", [], "any", false, false, false, 17), 'widget');
        echo "
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t";
        // line 20
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 20, $this->source); })()), "prenom_nom_user_entreprise", [], "any", false, false, false, 20), 'label', ["label" => "Prénom Nom utilisateur:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 22
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 22, $this->source); })()), "prenom_nom_user_entreprise", [], "any", false, false, false, 22), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 26
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 26, $this->source); })()), "fonction_entreprise", [], "any", false, false, false, 26), 'label', ["label" => "Fonction Entreprise:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 28
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 28, $this->source); })()), "fonction_entreprise", [], "any", false, false, false, 28), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 32
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 32, $this->source); })()), "siren_entreprise", [], "any", false, false, false, 32), 'label', ["label" => "Siren Entreprise:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })()), "siren_entreprise", [], "any", false, false, false, 34), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 38
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 38, $this->source); })()), "statut_entreprise", [], "any", false, false, false, 38), 'label', ["label" => "Statut juridique Entreprise:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 40
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 40, $this->source); })()), "statut_entreprise", [], "any", false, false, false, 40), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 44, $this->source); })()), "email_entreprise", [], "any", false, false, false, 44), 'label', ["label" => "Email Entreprise:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 46, $this->source); })()), "email_entreprise", [], "any", false, false, false, 46), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 50
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 50, $this->source); })()), "telephone_entreprise", [], "any", false, false, false, 50), 'label', ["label" => "Téléphone Entreprise:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 52
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 52, $this->source); })()), "telephone_entreprise", [], "any", false, false, false, 52), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 56
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 56, $this->source); })()), "adresse_entreprise", [], "any", false, false, false, 56), 'label', ["label" => "Adresse Entreprise:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 58
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 58, $this->source); })()), "adresse_entreprise", [], "any", false, false, false, 58), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 62
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 62, $this->source); })()), "ville_entreprise", [], "any", false, false, false, 62), 'label', ["label" => "Ville:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 64
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 64, $this->source); })()), "ville_entreprise", [], "any", false, false, false, 64), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 68
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 68, $this->source); })()), "cp_entreprise", [], "any", false, false, false, 68), 'label', ["label" => "Code postal:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 70
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 70, $this->source); })()), "cp_entreprise", [], "any", false, false, false, 70), 'widget');
        echo "
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t";
        // line 74
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 74, $this->source); })()), "mdp_entreprise", [], "any", false, false, false, 74), 'label', ["label" => "Mot de passe:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 76
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 76, $this->source); })()), "mdp_entreprise", [], "any", false, false, false, 76), "first", [], "any", false, false, false, 76), 'widget');
        echo "
\t\t\t\t\t<br/>

\t\t\t\t\t";
        // line 79
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 79, $this->source); })()), "mdp_entreprise", [], "any", false, false, false, 79), 'label', ["label" => "Confirmer le mot de passe:"]);
        echo "
\t\t\t\t\t<br/>
\t\t\t\t\t";
        // line 81
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 81, $this->source); })()), "mdp_entreprise", [], "any", false, false, false, 81), "second", [], "any", false, false, false, 81), 'widget');
        echo "
\t\t\t\t</p>
\t\t\t\t

\t\t\t\t<p>
\t\t\t\t\t<input type=\"submit\" class=\"btn btn-info\" style=\"margin-top: 100px\" value=\"Valider\">
\t\t\t\t</p>
\t\t\t\t
\t\t\t";
        // line 89
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 89, $this->source); })()), 'form_end');
        echo "
\t\t</div>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "insc_entre/form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  230 => 89,  219 => 81,  214 => 79,  208 => 76,  203 => 74,  196 => 70,  191 => 68,  184 => 64,  179 => 62,  172 => 58,  167 => 56,  160 => 52,  155 => 50,  148 => 46,  143 => 44,  136 => 40,  131 => 38,  124 => 34,  119 => 32,  112 => 28,  107 => 26,  100 => 22,  95 => 20,  89 => 17,  83 => 15,  77 => 12,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t<h1>Création Compte Entreprise</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t{# form : variable envoyée par le contrôleur #}
\t\t\t{{ form_start(form, { attr: { novalidate: 'novalidate' } } ) }}
\t\t\t\t<p>
\t\t\t\t\t{# provient de la classe de formulaire (Insc_entreType) #}
\t\t\t\t\t{{ form_label(form.nom_entreprise, 'Nom Entreprise:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.nom_entreprise) }}
\t\t\t\t</p>
\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.prenom_nom_user_entreprise, 'Prénom Nom utilisateur:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.prenom_nom_user_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.fonction_entreprise, 'Fonction Entreprise:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.fonction_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.siren_entreprise, 'Siren Entreprise:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.siren_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.statut_entreprise, 'Statut juridique Entreprise:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.statut_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.email_entreprise, 'Email Entreprise:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.email_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.telephone_entreprise, 'Téléphone Entreprise:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.telephone_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.adresse_entreprise, 'Adresse Entreprise:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.adresse_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.ville_entreprise, 'Ville:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.ville_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.cp_entreprise, 'Code postal:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.cp_entreprise) }}
\t\t\t\t</p>

\t\t\t\t<p>
\t\t\t\t\t{{ form_label(form.mdp_entreprise, 'Mot de passe:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.mdp_entreprise.first) }}
\t\t\t\t\t<br/>

\t\t\t\t\t{{ form_label(form.mdp_entreprise, 'Confirmer le mot de passe:') }}
\t\t\t\t\t<br/>
\t\t\t\t\t{{ form_widget(form.mdp_entreprise.second) }}
\t\t\t\t</p>
\t\t\t\t

\t\t\t\t<p>
\t\t\t\t\t<input type=\"submit\" class=\"btn btn-info\" style=\"margin-top: 100px\" value=\"Valider\">
\t\t\t\t</p>
\t\t\t\t
\t\t\t{{ form_end(form) }}
\t\t</div>
\t</div>
{% endblock %}", "insc_entre/form.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\insc_entre\\form.html.twig");
    }
}
