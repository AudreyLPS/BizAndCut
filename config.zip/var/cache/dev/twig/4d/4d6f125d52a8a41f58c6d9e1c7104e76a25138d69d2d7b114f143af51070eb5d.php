<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entreprise/devis/index.html.twig */
class __TwigTemplate_432a5a614bee9294d955e32d51ce85a001b4a4e36f77ccc214e5d12d4589778f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "entreprise/devis/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "entreprise/devis/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "entreprise/devis/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t";
        // line 6
        $this->loadTemplate("_inc/flash.messages.html.twig", "entreprise/devis/index.html.twig", 6)->display($context);
        // line 7
        echo "\t\t\t<h1>Gestion des événements</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<p class=\"text-right\">
\t\t\t<a href=\"";
        // line 18
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.devis.form");
        echo "\" class=\"btn btn-success\">+ Nouvel événement</a>\t\t
\t\t</p>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Evénement</th>
\t\t\t\t<th>Date</th>
\t\t\t\t<th>Durée</th>
\t\t\t\t<th>Nombre de participant</th>
\t\t\t\t<th>Status</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 29, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["devis"]) {
            echo " 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["devis"], "libelle", [], "any", false, false, false, 31), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-1\">";
            // line 32
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["devis"], "date", [], "any", false, false, false, 32), "m/d/Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">
\t\t\t\t\t\t";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["devis"], "heureDebut", [], "any", false, false, false, 34), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["devis"], "heureFin", [], "any", false, false, false, 34), "html", null, true);
            echo "
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["devis"], "nbParticipants", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["devis"], "devisStatut", [], "any", false, false, false, 37), "texteDevisStatut", [], "any", false, false, false, 37), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t";
            // line 39
            if (1 === twig_compare(twig_date_converter($this->env), twig_get_attribute($this->env, $this->source, $context["devis"], "date", [], "any", false, false, false, 39))) {
                // line 40
                echo "\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.satisfaction.send", ["event" => twig_get_attribute($this->env, $this->source, $context["devis"], "libelle", [], "any", false, false, false, 40)]), "html", null, true);
                echo "\" class=\"btn btn-dark col-md-12\">Generer enquete de satisfaction</a>

\t\t\t\t\t";
            } else {
                // line 43
                echo "\t\t\t\t\t\t";
                if (0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["devis"], "devisStatut", [], "any", false, false, false, 43), "texteDevisStatut", [], "any", false, false, false, 43), "Accepté")) {
                    // line 44
                    echo "\t\t\t\t\t\t\t<a href=\"";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.devis.form.update", ["id" => twig_get_attribute($this->env, $this->source, $context["devis"], "id", [], "any", false, false, false, 44)]), "html", null, true);
                    echo "\" class=\"btn btn-dark col-md-6\">Editer l'évenement</a>
\t\t\t\t\t\t";
                } else {
                    // line 45
                    echo "\t
\t\t\t\t\t\t\t<a href=\"";
                    // line 46
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.propositions.index", ["idDevis" => twig_get_attribute($this->env, $this->source, $context["devis"], "id", [], "any", false, false, false, 46)]), "html", null, true);
                    echo "\" class=\"btn btn-dark col-md-6\">Liste propositions</a>
\t\t\t\t\t\t
\t\t\t\t\t\t";
                }
                // line 49
                echo "\t\t\t\t\t<!--a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("entreprise.devis.delete", ["id" => twig_get_attribute($this->env, $this->source, $context["devis"], "id", [], "any", false, false, false, 49)]), "html", null, true);
                echo "\" class=\"btn btn-danger col-md-4\">Supprimer</a-->
\t\t\t\t\t";
            }
            // line 51
            echo "\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['devis'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "\t\t</table>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "entreprise/devis/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 54,  166 => 51,  160 => 49,  154 => 46,  151 => 45,  145 => 44,  142 => 43,  135 => 40,  133 => 39,  128 => 37,  124 => 36,  117 => 34,  112 => 32,  108 => 31,  101 => 29,  87 => 18,  74 => 7,  72 => 6,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t{% include \"_inc/flash.messages.html.twig\" %}
\t\t\t<h1>Gestion des événements</h1>
\t\t</div>
\t</div>
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<p class=\"text-right\">
\t\t\t<a href=\"{{ url('entreprise.devis.form') }}\" class=\"btn btn-success\">+ Nouvel événement</a>\t\t
\t\t</p>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Evénement</th>
\t\t\t\t<th>Date</th>
\t\t\t\t<th>Durée</th>
\t\t\t\t<th>Nombre de participant</th>
\t\t\t\t<th>Status</th>
\t\t\t\t<th>Actions</th>
\t\t\t</tr>
\t\t\t{% for devis in results %} 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">{{ devis.libelle }}</td>
\t\t\t\t\t<td class=\"col-md-1\">{{ devis.date|date(\"m/d/Y\") }}</td>
\t\t\t\t\t<td class=\"col-md-2\">
\t\t\t\t\t\t{{ devis.heureDebut }} - {{ devis.heureFin }}
\t\t\t\t\t</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ devis.nbParticipants }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ devis.devisStatut.texteDevisStatut }}</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t{% if date() > devis.date %}
\t\t\t\t\t\t<a href=\"{{ url('entreprise.satisfaction.send', { event:devis.libelle }) }}\" class=\"btn btn-dark col-md-12\">Generer enquete de satisfaction</a>

\t\t\t\t\t{% else %}
\t\t\t\t\t\t{% if devis.devisStatut.texteDevisStatut == \"Accepté\" %}
\t\t\t\t\t\t\t<a href=\"{{ url('entreprise.devis.form.update', { id:devis.id }) }}\" class=\"btn btn-dark col-md-6\">Editer l'évenement</a>
\t\t\t\t\t\t{% else %}\t
\t\t\t\t\t\t\t<a href=\"{{ url('entreprise.propositions.index', { idDevis:devis.id }) }}\" class=\"btn btn-dark col-md-6\">Liste propositions</a>
\t\t\t\t\t\t
\t\t\t\t\t\t{% endif %}
\t\t\t\t\t<!--a href=\"{{ url('entreprise.devis.delete', { id:devis.id }) }}\" class=\"btn btn-danger col-md-4\">Supprimer</a-->
\t\t\t\t\t{% endif %}
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t{% endfor %}
\t\t</table>
\t</div>
{% endblock %}

", "entreprise/devis/index.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\entreprise\\devis\\index.html.twig");
    }
}
