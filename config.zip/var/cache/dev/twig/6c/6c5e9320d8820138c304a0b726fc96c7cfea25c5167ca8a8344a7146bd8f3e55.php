<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* coiffeur/propositions/index.html.twig */
class __TwigTemplate_062ff15ebdec3fc2b6cf602f842fad900ac52ce6c4e61f29984f0a4335b6e011 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "coiffeur/propositions/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "coiffeur/propositions/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "coiffeur/propositions/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t";
        // line 6
        $this->loadTemplate("_inc/flash.messages.html.twig", "coiffeur/propositions/index.html.twig", 6)->display($context);
        // line 7
        echo "\t\t\t<h1>Liste des propositions</h1>
\t\t</div>
\t</div>

\t
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Nom Entreprise</th>
\t\t\t\t<th>Adresse Entreprise</th>
\t\t\t\t<th>Date Evénement</th>
\t\t\t\t<th>Heure début Evénement</th>
\t\t\t\t<th>Heure fin Evénement</th>
\t\t\t\t<th>Nombre de coiffeur</th>
\t\t\t\t<th>Montant Proposition</th>
\t\t\t</tr>
\t\t\t";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["propositions"]) || array_key_exists("propositions", $context) ? $context["propositions"] : (function () { throw new RuntimeError('Variable "propositions" does not exist.', 29, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["proposition"]) {
            echo " 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "nomEntrepriseProposition", [], "any", false, false, false, 31), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "adresseEntrepriseProposition", [], "any", false, false, false, 32), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 33
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "dateProposition", [], "any", false, false, false, 33), "m/d/Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "heureProposition", [], "any", false, false, false, 34), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "heureFProposition", [], "any", false, false, false, 35), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "nbCoiffeursProposition", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-2\">";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["proposition"], "montantProposition", [], "any", false, false, false, 37), "html", null, true);
            echo "</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t\t";
            // line 40
            echo "\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['proposition'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "\t\t</table>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "coiffeur/propositions/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 43,  134 => 40,  129 => 37,  125 => 36,  121 => 35,  117 => 34,  113 => 33,  109 => 32,  105 => 31,  98 => 29,  74 => 7,  72 => 6,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
\t<div class=\"row\">
\t\t<div class=\"col\">
\t\t\t{% include \"_inc/flash.messages.html.twig\" %}
\t\t\t<h1>Liste des propositions</h1>
\t\t</div>
\t</div>

\t
\t<div class=\"row\">
\t<div class=\"col-md-12\">
\t
    <p class=\"text-right\">
        
    </p>
\t</div>
\t\t<table class=\"table table-striped\">
\t\t\t<tr>
\t\t\t\t<th>Nom Entreprise</th>
\t\t\t\t<th>Adresse Entreprise</th>
\t\t\t\t<th>Date Evénement</th>
\t\t\t\t<th>Heure début Evénement</th>
\t\t\t\t<th>Heure fin Evénement</th>
\t\t\t\t<th>Nombre de coiffeur</th>
\t\t\t\t<th>Montant Proposition</th>
\t\t\t</tr>
\t\t\t{% for proposition in propositions %} 
\t\t\t\t<tr>
\t\t\t\t\t<td class=\"col-md-1\">{{ proposition.nomEntrepriseProposition }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.adresseEntrepriseProposition }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.dateProposition|date(\"m/d/Y\") }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.heureProposition }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.heureFProposition }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.nbCoiffeursProposition }}</td>
\t\t\t\t\t<td class=\"col-md-2\">{{ proposition.montantProposition }}</td>
\t\t\t\t\t<td class=\"col-md-4\">
\t\t\t\t\t\t{# <a href=\"{{ url('coiffeur.propositions.accepte', { id:proposition.id, idPropositions:proposition.devis.numeroDevis }) }}\" class=\"btn btn-success col-md-4\">Accepter</a> #}
\t\t\t\t\t</td>
\t\t\t\t</tr>
\t\t\t{% endfor %}
\t\t</table>
\t</div>
{% endblock %}









", "coiffeur/propositions/index.html.twig", "C:\\Users\\audre\\Desktop\\BizAndCut\\templates\\coiffeur\\propositions\\index.html.twig");
    }
}
